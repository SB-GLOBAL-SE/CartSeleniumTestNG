#!/bin/bash

zip -r server_side_test_package pom.xml run-tests.sh src